package Ejercicio5;

public class CocheCRUDImpl implements CocheCRUD {

    public CocheCRUDImpl(){

    }

    public void save() {
        System.out.println("Método SAVE");

    }

    public void findAll() {
        System.out.println("Método FINDALL");
    }

    public void delete() {
        System.out.println("Método DELETE");
    }
}
