package poo.clases;

// las clases son las plantillas de los objetos
// ayudan a no tener que duplicar código
// por ejemplo: tener la plantilla "coche"
// y que cada uno tuviera sus particularidades (color, tamaños)
// Aquí se crean los objetos.
// Formato: nombre de la clase, identificador, operador new y nombre de clase();

import poo.herencia.Camion;
import poo.herencia.Coche;
import poo.herencia.Motocicleta;

public class Main {

    public static void main(String[] args) {
        // 1.- Clases y objetos
        // Clase identificador = new Clase (){}
        // crear un objeta usando el constructor vacío

        Vehiculo toyotaPrius = new Vehiculo();

        // crear un objeta usando el constructor con parámetros (cmd + P)
        Motor motorGTI = new Motor("GTI",190,459.0,6);

        Vehiculo fordMondeo = new Vehiculo("Ford", "Mondeo", 2.1, 2010,false, 0,motorGTI);

        System.out.println(fordMondeo.fabricante);
        System.out.println(fordMondeo.year);
        System.out.println(fordMondeo.speed); // 0
        fordMondeo.acelerar(50);
        System.out.println(fordMondeo.speed); // 50

        //c2.- herencia

        Motocicleta kawasakiNinja = new Motocicleta();
        kawasakiNinja.fabricante = "Kawasaki";

        System.out.println("Fin de programa");

        // 3.- Polimorfismo
        Vehiculo vehiculo;

        vehiculo = new Motocicleta();
        vehiculo.acelerar(50);

        vehiculo = new Coche();
        vehiculo.acelerar(50);

        vehiculo = new Camion();
        vehiculo.acelerar(50);

        System.out.println(kawasakiNinja.speed);
        kawasakiNinja.acelerar(250);
        System.out.println(kawasakiNinja.speed);

        // 4.- Clases abstractas: no se pueden instanciar (crear un objeto).
        // Sólo se instancian las clases hijas.
        // public abstrac class Vehiculo {}
    }
}
