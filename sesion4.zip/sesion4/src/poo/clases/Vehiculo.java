package poo.clases;

// clase (plantilla) vehículo

public class Vehiculo {

    // 1.- Atributos

    protected String fabricante;
    protected String modelo;
    protected double cc;
    protected int year;
    protected boolean sport;
    protected int speed;
    protected Motor motor;

    // 2.- Constructores

    /*
    Funciones y métodos que ayudan a construir los objetos
    a partir de la plantilla
     */

     // el nombre del constructor tiene que ser igual
    // que el de la clase.
    // este constructor se crea vacío, sin variables
    // para el ejemplo.

    public Vehiculo(){

    }

    /*
    Podemos usar la sobrecarga para crear otro constructor
    con el mismo nombre pero con parámetros o variables distintos
     */

    public Vehiculo(String fabricante, String modelo, double cc, int year, boolean sport, int speed, Motor motor) {
        this.fabricante = fabricante;
        this.modelo = modelo;
        this.cc = cc;
        this.year = year;
        this.sport = sport;
        this.speed = speed;
        this.motor = motor;
    }

    public Vehiculo(String fabricante, String modelo){ //atributos
        this.fabricante = fabricante; // parámetro
        this.modelo = modelo;

    }

    public Vehiculo(String fabricante, int year) {
        this.fabricante = fabricante;
        this.year = year;
    }
// 3.- Métodos (comportamiento)

    public void acelerar(int quantity){
        this.speed += quantity;
    }

// getter y setter



    // to stream

}
