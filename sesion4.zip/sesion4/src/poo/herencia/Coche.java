package poo.herencia;

import poo.clases.Vehiculo;

public class Coche extends Vehiculo {

    int numPuertas;
}
