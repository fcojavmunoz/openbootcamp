package poo.herencia;

import poo.clases.Vehiculo;

public class Camion extends Vehiculo {
    
    double capacidadCarga;

    public Camion(){

    }

}
