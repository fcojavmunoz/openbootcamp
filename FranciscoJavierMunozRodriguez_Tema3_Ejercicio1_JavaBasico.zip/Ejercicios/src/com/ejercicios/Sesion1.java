package com.ejercicios;

public class Sesion1 {


        public static void main(String[] args) {

            byte number1 = 1; // 1 byte
            short number2 = 2; // 2 byte
            int number3 = 3; // 4 byte
            long number4 = 4; // 8 byte

            float decimal1 = 4.9f;
            double decimal2 = 9.99d;

            char caracter1 = 'a';
            String texto = "La palabra booleano ";
            String texto2 = "rima con verano.";

            boolean verdadero = true;
            boolean falso = false;

            Integer numero = null;
            Long numero2 = 2L;

            System.out.println(number1);
            System.out.println(number2);
            System.out.println(number3);
            System.out.println(number4);
            System.out.println(decimal1);
            System.out.println(decimal2);
            System.out.println(caracter1);
            System.out.println(texto);
            System.out.println(texto2);
            System.out.println(verdadero);
            System.out.println(falso);
            System.out.println(numero);
            System.out.println(numero2);






        }
    }


