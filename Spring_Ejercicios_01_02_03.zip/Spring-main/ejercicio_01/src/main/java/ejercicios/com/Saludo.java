package ejercicios.com;

public class Saludo {

    public Saludo(){}

    public void imprimirSaludo(String saludo){
        System.out.println(saludo);
    }
}
